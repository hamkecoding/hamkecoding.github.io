function Check(){
    if()
}